from abc import ABC, abstractmethod
import turtle

class Game(ABC):

    def __init__(self, screenWidth=800, screenHeight=800, title="",color="black"):
        '''Initializes Game screen and turtle drawer
        then calls self.titleScreen'''
        self.screen = turtle.Screen()
        self.screenWidth =screenWidth
        self.screenHeight = screenHeight
        self.screen.setup(screenWidth, screenHeight)
        self.screen.bgcolor(color)
        self.screen.title(title)

        self.screen.cv._rootwindow.resizable(False, False)



        self.screen.tracer(False)

        self.drawer = turtle.Turtle()
        self.drawer.hideturtle()
        self.drawer.penup()

        self.gameOver = False

        self.titleScreen()

    def play(self):
        '''Handles actually playing the game'''
        self.screen.listen()
        self.screen.mainloop()

    # def clear(self):
    #     '''Clears screen's onclick and drawer'''
    #     # hide title screen logo if present
    #     if hasattr(self, "logoTurtle"):
    #         self.logoTurtle.hideturtle()
    #     self.screen.onclick(None)
    #     self.drawer.clear()

    def clear(self):
        # Clear the drawing turtle
        self.drawer.clear()

        # Safely hide logoTurtle if subclass created it
        if hasattr(self, "logoTurtle") and self.logoTurtle is not None:
            try:
                self.logoTurtle.hideturtle()
            except:
                pass

        # Safely hide other possible screen elements if needed
        if hasattr(self, "gameOverImg") and self.gameOverImg is not None:
            try:
                self.gameOverImg.hideturtle()
            except:
                pass


    @abstractmethod
    def createMainPlayer(self):
        ''' Creates a main player and returns it'''
        pass

    @abstractmethod
    def titleScreen(self):
        ''' Creates the title screen'''
        pass

    @abstractmethod
    def createGameScreen(self):
        ''' Creates the game screen'''
        pass

    @abstractmethod
    def createGameScreenEvents(self):
        ''' Creates the events for the game screen'''
        pass

    @abstractmethod
    def createResultScreen(self, result):
        ''' Creates the end screen, which could contain the score and button to restart the game (extensions)'''
        pass


    class Button:

        def __init__(self, turtleDrawer: turtle.Turtle, topLeftX: int, topLeftY: int, bottomRightX: int, bottomRightY: int, buttonText: str, borderColor = "Black", fillColor = "White", fontColor = "Blue", fontSize: int = 12):
            self.turt = turtleDrawer
            self.topLeftX = topLeftX
            self.topLeftY = topLeftY
            self.bottomRightX = bottomRightX
            self.bottomRightY = bottomRightY
            self.text = buttonText
            self.fill = fillColor
            self.font = ('Pixel Game', fontSize, 'normal')
            self.fontColor = fontColor
            self.borderColor = borderColor
            self.draw()
        
        def draw(self):
            ''' This function draws the button using the turtleDrawer given in the constructor'''
            self.turt.goto(self.topLeftX, self.topLeftY)
            self.turt.setheading(0)
            self.turt.color(self.borderColor)

            if self.fill: # Begins filling if fillColor was given in constructor
                self.turt.fillcolor(self.fill)
                self.turt.begin_fill()
            
            self.turt.pendown()
            self.turt.width(5)
            for i in range(2): # Draws the boundary of the button
                self.turt.forward(self.bottomRightX-self.topLeftX)
                self.turt.right(90)
                self.turt.forward(self.topLeftY - self.bottomRightY)
                self.turt.right(90)
            self.turt.penup()

            if self.fill:
                self.turt.end_fill()

            # Draws the text in the center of the box
            self.turt.goto(int((self.topLeftX + self.bottomRightX)/2), 
                           int((self.topLeftY + self.bottomRightY)/2) - self.font[1])
            self.turt.pencolor(self.fontColor)
            self.turt.write(self.text, align = "center", font = self.font)

        def pointInside(self, pointX: int, pointY: int) -> bool:
            ''' This function returns True if the point given by (pointX, pointY) is within the 
                bounds of the button given in the constructor'''
            return (pointX >= self.topLeftX
                and pointX <= self.bottomRightX
                and pointY >= self.bottomRightY
                and pointY <= self.topLeftY)
        
        def resize(self, newFontSize):
            """Redraw the button with a new font size."""
            # Update stored font size
            self.font = ('Arial', newFontSize, 'normal')

            # Clear old text & border
            self.turt.clear()

            # Redraw button
            self.draw()



if __name__ == "__main__":
    turtleDrawer = turtle.Turtle()
    screen = turtle.Screen()
    turtleDrawer.penup()
    turtleDrawer.hideturtle()
    screen.tracer(0)

    quitButton = Game.Button(turtleDrawer, -50, 50, 50, -50, "Click Me\nTo Quit", borderColor="Red", 
                         fillColor="Green", fontColor="Blue", fontSize=13)

    def clickFunction(mouseX, mouseY):
        if quitButton.pointInside(mouseX, mouseY):
            print("Quit clicked")
            turtle.bye()

    screen.onclick(clickFunction)
    screen.listen()
    screen.mainloop()