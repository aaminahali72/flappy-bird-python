'''
asteroids.py
Simple implementation of an asteroid game
Aaminah Ali
CS 151: Computational Thinking: Visual Media
Fall 2025

Game design taken by Brian Marks
'''

import turtle as t
import random as random

class Game:
    screen = t.Screen()

    def __init__(self):
        #Screen setup
        self.screen.screensize(800, 800, "blue")
        self.screen.tracer(0)
        self.speed = 20
        self.turnRate = 10

        #Player
        self.player = self.makePlayer()

        #Start flag
        self.game_started = False

        #Start screen text
        self.start_text = t.Turtle()
        self.start_text.hideturtle()
        self.start_text.color("white")
        self.start_text.penup()
        self.start_text.goto(0, 50)
        self.start_text.write("ASTEROIDS\nPress SPACE to Start",align="center",font=("Arial", 24, "bold"))

        #Enemy spawn region
        self.enemy_min_x = -300
        self.enemy_max_x = 300
        self.enemy_min_y = -300
        self.enemy_max_y = 300

        #Enemies
        self.enemies = self.makeEnemies(5)
        self.collision_radius = 30

        #Bullets
        self.bullets = []

        #Score setup
        self.score = 0
        self.scorekeeper = t.Turtle()
        self.scorekeeper.hideturtle()
        self.scorekeeper.penup()
        self.scorekeeper.color("white")
        self.scorekeeper.goto(-380, 360)
        self.updateScoreDisplay()

        #Event setup
        self.setupEvents()

    def updateScoreDisplay(self):
        '''Method to show score'''
        self.scorekeeper.clear()
        self.scorekeeper.write(f"Score: {self.score}", font=("Arial", 16, "normal"))

    def play(self):
        '''Method to play'''
        self.screen.listen()
        self.screen.update()
        self.screen.mainloop()

    def makePlayer(self):
        '''Method to make player'''
        player = t.Turtle()

        #Register all 36 rotated images
        for i in range(36):
            heading = i * 10
            shape_path = f'rocketships/Rocketship{heading}.gif'
            Game.screen.register_shape(shape_path)

        player.penup()
        player.setheading(0)
        player.shape("rocketships/Rocketship0.gif")
        return player

    def placeEnemyRandomly(self, turt):
        '''Method to place enemies randomly'''
        x = random.randint(self.enemy_min_x, self.enemy_max_x)
        y = random.randint(self.enemy_min_y, self.enemy_max_y)
        turt.penup()
        turt.goto(x, y)

    def makeEnemies(self, n):
        '''Method to make enemies'''
        enemies = []
        for i in range(n):
            enemy = t.Turtle()
            enemy.shape("square")
            enemy.color("red")
            enemy.penup()
            self.placeEnemyRandomly(enemy)
            enemies.append(enemy)
        return enemies


    def moveEnemiesRandomly(self):
        '''Method to move enemies randomly'''
        if not self.game_started:
            return

        for enemy in self.enemies:
            x, y = enemy.xcor(), enemy.ycor()
            dx = random.randint(-20, 20)
            dy = random.randint(-20, 20)
            new_x = min(max(x + dx, self.enemy_min_x), self.enemy_max_x)
            new_y = min(max(y + dy, self.enemy_min_y), self.enemy_max_y)
            enemy.goto(new_x, new_y)

        self.screen.update()
        self.screen.ontimer(self.moveEnemiesRandomly, 50)


    def checkForCollisions(self):
        '''Method to check for collisions'''
        if not self.game_started:
            return

        self.score += 1
        self.updateScoreDisplay()

        for enemy in self.enemies:
            if self.player.distance(enemy) < self.collision_radius:
                self.gameOver()
                return

        self.screen.update()
        self.screen.ontimer(self.checkForCollisions, 50)


    def gameOver(self):
        '''Method to declare game is over'''
        self.screen.clear()
        self.screen.bgcolor("black")

        message = t.Turtle()
        message.hideturtle()
        message.color("red")
        message.write(f"GAME OVER\nFinal Score: {self.score}\n\nPress SPACE to Replay", align="center", font=("Arial", 24, "bold"))

        self.screen.onkeypress(self.resetGame, "space")
        self.screen.listen()

    def up(self):
        '''Method to move up'''
        if not self.game_started:
            return
        self.player.forward(self.speed)
        self.screen.update()

    def down(self):
        '''Method to move down'''
        if not self.game_started:
            return
        self.player.back(self.speed)
        self.screen.update()

    def left(self):
        '''Method to turn left'''
        if not self.game_started:
            return

        self.player.left(self.turnRate)

        # Smooth rotation 
        heading = int(round(self.player.heading() / 10) * 10) % 360
        self.player.shape(f"rocketships/Rocketship{heading}.gif")

        self.screen.update()

    def right(self):
        '''Method to turn right'''
        if not self.game_started:
            return

        self.player.right(self.turnRate)

        #Smooth rotation 
        heading = int(round(self.player.heading() / 10) * 10) % 360
        self.player.shape(f"rocketships/Rocketship{heading}.gif")

        self.screen.update()

    # --------------------------- EVENT BINDINGS ---------------------------

    def setupEvents(self):
        '''Method to set up events'''
        #Movement keys (always bound, but do nothing before game starts)
        Game.screen.onkeypress(self.up, "Up")
        Game.screen.onkeypress(self.down, "Down")
        Game.screen.onkeypress(self.left, "Left")
        Game.screen.onkeypress(self.right, "Right")

        #Bullets
        Game.screen.onkeypress(self.fireBullet, "s")

        #Start/Restart
        Game.screen.onkeypress(self.startGame, "space")

        #Quit
        Game.screen.onkeypress(Game.screen.bye, "q")


    def startGame(self):
        '''Method to start game'''
        if self.game_started:
            return

        self.game_started = True
        self.start_text.clear()

        self.screen.ontimer(self.moveEnemiesRandomly, 50)
        self.screen.ontimer(self.checkForCollisions, 50)
        self.screen.ontimer(self.moveBullets, 20)
        self.screen.ontimer(self.spawnEnemiesPeriodically, 5000)

        self.screen.listen()



    def fireBullet(self):
        '''Method to fire bullets'''
        if not self.game_started:
            return

        bullet = t.Turtle()
        bullet.shape("circle")
        bullet.color("yellow")
        bullet.shapesize(0.3, 0.3)
        bullet.penup()
        bullet.setheading(self.player.heading())
        bullet.goto(self.player.xcor(), self.player.ycor())
        self.bullets.append(bullet)


    def moveBullets(self):
        '''Method to move bullets'''
        if not self.game_started:
            return

        for bullet in self.bullets[:]:
            bullet.forward(20)

            #Remove if off screen
            if abs(bullet.xcor()) > 450 or abs(bullet.ycor()) > 450:
                bullet.hideturtle()
                self.bullets.remove(bullet)
                continue

            #Check hits
            for enemy in self.enemies:
                if bullet.distance(enemy) < 20:
                    bullet.hideturtle()
                    self.bullets.remove(bullet)

                    self.placeEnemyRandomly(enemy)

                    self.score += 10
                    self.updateScoreDisplay()
                    break

        self.screen.update()
        self.screen.ontimer(self.moveBullets, 20)



    def spawnEnemy(self):
        '''Method to spawn an enemy'''
        enemy = t.Turtle()
        enemy.shape("square")
        enemy.color("red")
        enemy.penup()
        self.placeEnemyRandomly(enemy)
        self.enemies.append(enemy)

    def spawnEnemiesPeriodically(self):
        '''Method to spawn enemies periodically for a certain time'''
        if not self.game_started:
            return

        self.spawnEnemy()
        self.screen.ontimer(self.spawnEnemiesPeriodically, 5000)


    def resetGame(self):
        '''Method to reset the game'''

        self.screen.clear()
        self.screen.bgcolor("blue")

        self.game_started = False

        self.player = self.makePlayer()
        self.score = 0
        self.enemies = self.makeEnemies(5)

        self.scorekeeper = t.Turtle()
        self.scorekeeper.hideturtle()
        self.scorekeeper.penup()
        self.scorekeeper.color("white")
        self.scorekeeper.goto(-380, 360)
        self.updateScoreDisplay()

        self.start_text = t.Turtle()
        self.start_text.hideturtle()
        self.start_text.color("white")
        self.start_text.penup()
        self.start_text.goto(0, 50)
        self.start_text.write("ASTEROIDS\nPress SPACE to Start", align="center", font=("Arial", 24, "bold"))

        self.setupEvents()
        self.screen.update()

#Main code
def main():
    game = Game()
    game.play()

if __name__ == '__main__':
    main()
